const registeredBlockComponents = {};

export { registeredBlockComponents };
