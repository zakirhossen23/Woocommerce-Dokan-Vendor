export const PAYMENT_METHOD_NAME = 'payment_request';

export const DEFAULT_STRIPE_EVENT_HANDLERS = {
	shippingAddressChange: null,
	shippingOptionChange: null,
	source: null,
};
