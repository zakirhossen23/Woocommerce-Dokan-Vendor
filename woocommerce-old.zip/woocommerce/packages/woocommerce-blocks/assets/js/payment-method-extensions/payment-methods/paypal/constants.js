export const PAYMENT_METHOD_NAME = 'paypal';
