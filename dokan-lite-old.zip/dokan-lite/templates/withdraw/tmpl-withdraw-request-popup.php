<script type="text/html" id="tmpl-withdraw-request-popup">
    <div id="withdraw-request-popup" class="white-popup dokan-withdraw-popup">
        <div id="dokan-send-withdraw-request-popup-form">
            <h2><i class="fa fa-money" aria-hidden="true"></i>&nbsp;<?php esc_html_e( 'Send Withdraw Request', 'dokan-lite' ); ?></h2>
            <?php do_action( 'dokan_send_withdraw_request_popup_form_content' ); ?>
        </div>
    </div>
</script>
