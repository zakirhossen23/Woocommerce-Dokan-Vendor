<?php

use WeDevs\Dokan\Dashboard\Templates\Products;

class Dokan_Template_Products extends Products {}
