<?php
/**
 * Portfolio Loop End
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 		PressLayouts
 * @package 	Kapee/template-parts/portfolio
 * @since 	1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</div>
