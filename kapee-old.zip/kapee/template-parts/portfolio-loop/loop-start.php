<?php
/**
 * Portfolio loop stat
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 		PressLayouts
 * @package 	Kapee/template-parts/portfolio
 * @since 	1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="<?php kapee_portfolio_wrapper_classes();?>">